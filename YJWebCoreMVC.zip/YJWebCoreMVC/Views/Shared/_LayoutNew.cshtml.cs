using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace YJWebCoreMVC.Views.Shared
{
    public class _LayoutNewModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
