using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace YJWebCoreMVC.Views.SalesSummary
{
    public class SalesSummaryModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
