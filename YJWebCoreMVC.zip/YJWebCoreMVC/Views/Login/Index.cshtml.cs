using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace YJWebCoreMVC.Views.Login
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
