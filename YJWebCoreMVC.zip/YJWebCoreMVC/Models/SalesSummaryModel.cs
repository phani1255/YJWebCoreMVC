﻿namespace YJWebCoreMVC.Models
{
    public class SalesSummaryModel
    {
        public string DateFrom { get; set; }
        public string DateTo { get; set; }
        public bool iSPartial { get; set; }
        public bool bypickdate { get; set; }
        public int type { get; set; }

    }
}
